#include "bsp.h"
uint8_t tftdata[10]={0x5A,0XA5,0X05,0X82,0X00,0x03,0X10,0x28};  //�޸ı���0000 ��ֵ
uint8_t tftcmd[10]={0x5A,0XA5,0X03,0X80,0X4f,0x03};     //ģ�ⰴ������
void bsp_diwen_changedata(uint8_t data_16)
{
      comSendBuf(COM1,tftdata,8);     
      comSendBuf(COM1,tftcmd,6);     
}
