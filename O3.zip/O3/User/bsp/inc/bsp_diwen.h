#ifndef BSP_DIWEN_H
#define BSP_DIWEN_H	 
	 
void bsp_diwen_changedata(uint8_t data_16);				    
#endif



