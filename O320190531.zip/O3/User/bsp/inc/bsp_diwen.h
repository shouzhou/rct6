#ifndef BSP_DIWEN_H
#define BSP_DIWEN_H	 
	 
void bsp_Diwen_Updatedata(uint16_t dataaddr,uint16_t data_16);			    
#endif



