
#include "bsp.h"			/* �ײ�Ӳ������ */
DHT11_T  g_DHT11;
uint16_t temp ,humi;
int main(void)
{
    uint8_t keyvalue;
    uint16_t  count=0;
    uint8_t ret,flag=0;
	bsp_Init();							/* Ӳ����ʼ�� */
	while (1)
	{
        keyvalue = bsp_KeyScan(0);
        if(keyvalue ==KEY1_PRES)  //K1 ����
        {
            flag ++ ;
             printf("KEY1 PRESSED \r\n");
             TIM_Cmd(TIM3,DISABLE);    
             TIM_Cmd(TIM6,DISABLE);
           
             ret = DHT11_ReadData(&g_DHT11); //��ȡ��ʪ��ֵ
             if (ret == 1)
			{
				printf("temp= %d  humi =  %d \r\n",g_DHT11.Temp, g_DHT11.Hum);
			}
			else
			{
				printf("\r\nδ����DHT22��ʪ�ȴ�����\r\n");
			}
             TIM_Cmd(TIM3,ENABLE);
             TIM_Cmd(TIM6,ENABLE);
//            bsp_IOToggle(1);
//            bsp_IOToggle(2);
//            bsp_IOToggle(3);
//            bsp_IOToggle(4);
            if(flag%2 ==0)
            {
                printf("high\r\n");
                bsp_IOOn(1);
                bsp_IOOn(2);
                bsp_IOOn(3);
                bsp_IOOn(4);
            }
            else 
            {
                printf("low\r\n");
                bsp_IOOff(1);
                bsp_IOOff(2);
                bsp_IOOff(3);
                bsp_IOOff(4);
            }
        }
        else if(keyvalue ==KEY2_PRES) //K2 ����
        {
            printf("KEY2 PRESSED \r\n");
            DemoEEPROM();  //eeprom ���Գ���
        }
         count++;
         if(count%1000 ==0)
         tim_print_result();
        if(count==2000)
        {
            count=0;
        }
         bsp_DelayMS(1);
        
	}
}







